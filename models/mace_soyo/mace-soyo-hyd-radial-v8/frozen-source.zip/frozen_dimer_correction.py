"""Apply the frozen v8 radial correction to an isolated two-atom system."""
import json
from pathlib import Path

import numpy as np

from fit_transfer_candidate import CENTERS, ELECTRONEGATIVITY, SCALE_RADII, WIDTH


def load_coefficients(path: Path):
    candidate = json.loads(path.read_text())
    coefficients = np.asarray(candidate["coefficients"], dtype=float)
    if candidate["family"] != "radial" or coefficients.shape != (len(CENTERS) * 4,):
        raise ValueError("Expected the frozen radial candidate")
    if not np.isfinite(coefficients).all():
        raise ValueError("Candidate has non-finite coefficients")
    return coefficients.reshape(len(CENTERS), 4)


def isolated_pair_correction(elements, positions, coefficients):
    """Return energy and equal-and-opposite forces in eV and eV/Å."""
    a, b = elements
    if any(element not in SCALE_RADII for element in (a, b)):
        return 0., np.zeros((2, 3))
    vector = np.asarray(positions[1]) - np.asarray(positions[0])
    distance = float(np.linalg.norm(vector))
    if not np.isfinite(distance) or distance <= 0.:
        raise ValueError("Expected two distinct finite atom positions")
    radius = SCALE_RADII[a] + SCALE_RADII[b]
    ena, enb = ELECTRONEGATIVITY[a], ELECTRONEGATIVITY[b]
    chemistry = np.array([1., (ena + enb - 5.) / 2., abs(ena - enb) / 2., (radius - 2.) / 2.])
    offset = distance / radius - CENTERS
    weighted = np.exp(-.5 * (offset / WIDTH) ** 2) * (coefficients @ chemistry)
    energy = float(weighted.sum())
    radial = float(weighted @ offset / (radius * WIDTH ** 2))
    force = radial * vector / distance
    return energy, np.stack((-force, force))
