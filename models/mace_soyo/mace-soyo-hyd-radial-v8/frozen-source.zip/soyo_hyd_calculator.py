"""ASE integration for the frozen isolated-dimer correction."""
from pathlib import Path

import numpy as np
from ase.calculators.calculator import all_changes
from ase.geometry import find_mic
from ase.stress import full_3x3_to_voigt_6_stress
from mace_soyo import MACESoyoCalculator

from frozen_dimer_correction import isolated_pair_correction, load_coefficients


def isolated_displacement(atoms, cutoff):
    if len(atoms) != 2:
        return None
    vector = atoms.positions[1] - atoms.positions[0]
    if not atoms.pbc.any():
        return vector
    active_cell = atoms.cell.array[atoms.pbc]
    shortest_bound = np.linalg.svd(active_cell, compute_uv=False)[-1]
    if shortest_bound <= 2 * cutoff:
        return None
    nearest, distance = find_mic(vector, atoms.cell, pbc=atoms.pbc)
    if shortest_bound - distance <= cutoff:
        return None
    return nearest


class MaceSoyoHydCalculator(MACESoyoCalculator):
    """Use the base potential everywhere, with an additive term for isolated dimers."""

    def __init__(self, package_path, correction_path, device="cuda:0"):
        super().__init__(package_path=str(package_path), head="salexmp", device=device, use_d3=False)
        self.coefficients = load_coefficients(Path(correction_path))

    def calculate(self, atoms=None, properties=("energy", "forces", "stress"), system_changes=all_changes):
        super().calculate(atoms, properties, system_changes)
        vector = isolated_displacement(self.atoms, float(self.cutoff))
        if vector is None:
            return
        delta_energy, delta_force = isolated_pair_correction(
            self.atoms.get_chemical_symbols(), np.stack((np.zeros(3), vector)), self.coefficients
        )
        self.results["energy"] += delta_energy
        if "free_energy" in self.results:
            self.results["free_energy"] += delta_energy
        self.results["forces"] += delta_force
        if self.atoms.pbc.all() and "stress" in self.results:
            stress = -np.outer(vector, delta_force[1]) / self.atoms.get_volume()
            self.results["stress"] += full_3x3_to_voigt_6_stress(stress)
