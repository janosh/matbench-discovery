"""Run frozen HYD energy and force prediction on batches of isolated dimers."""
import numpy as np
import torch
from ase.calculators.calculator import Calculator, all_changes
from mace_soyo.torchsim import MACESoyoTorchSimAOTIModel, atoms_to_state

from frozen_dimer_correction import isolated_pair_correction, load_coefficients
from soyo_hyd_calculator import MaceSoyoHydCalculator, isolated_displacement

BATCH_SIZE = 32


def key(atoms):
    return (atoms.numbers.tobytes(), atoms.positions.tobytes(), atoms.cell.array.tobytes(),
            atoms.pbc.tobytes())


class BatchedDimerCalculator(Calculator):
    """Populate the ASE cache lazily for one supplied set of neighboring requests."""

    implemented_properties = ["energy", "free_energy", "forces"]

    def __init__(self, package_path, correction_path, device, plan=None):
        super().__init__()
        self.model = MACESoyoTorchSimAOTIModel(
            package_path=str(package_path), head="salexmp", device=device,
            use_d3=False, compute_stress=False,
        )
        self.coefficients = load_coefficients(correction_path)
        self.plan = plan
        self.cached = {}

    def predict(self, systems):
        records = []
        for offset in range(0, len(systems), BATCH_SIZE):
            group = systems[offset:offset + BATCH_SIZE]
            if any(len(atoms) != 2 for atoms in group):
                raise ValueError("Dimer batch requires exactly two atoms per structure")
            energies, forces = self.predict_base(group)
            for atoms, energy, force in zip(group, energies, forces, strict=True):
                vector = isolated_displacement(atoms, self.model.cutoff)
                if vector is not None:
                    delta_energy, delta_force = isolated_pair_correction(
                        atoms.get_chemical_symbols(), np.stack((np.zeros(3), vector)), self.coefficients
                    )
                    energy += delta_energy
                    force = force.copy()
                    force += delta_force
                records.append({"energy": float(energy), "free_energy": float(energy), "forces": force.copy()})
        return records

    def predict_base(self, group):
        state = atoms_to_state(group, device=self.model.device, dtype=self.model.dtype)
        result = self.model(state)
        return (result["energy"].cpu().numpy().reshape(-1),
                result["forces"].cpu().numpy().reshape(len(group), 2, 3))

    def calculate(self, atoms=None, properties=("energy", "forces"), system_changes=all_changes):
        super().calculate(atoms, properties, system_changes)
        target = key(self.atoms)
        if target not in self.cached:
            group = self.plan(self.atoms) if self.plan else [self.atoms]
            keys = [key(atoms) for atoms in group]
            if target not in keys:
                group.append(self.atoms)
                keys.append(target)
            self.cached = dict(zip(keys, self.predict(group), strict=True))
        self.results = self.cached[target]


class CanonicalBatchedDimerCalculator(BatchedDimerCalculator):
    """Batch compiled calls while retaining the scalar ASE input conversion."""

    def __init__(self, package_path, correction_path, device, plan=None):
        Calculator.__init__(self)
        self.model = MaceSoyoHydCalculator(package_path, correction_path, device)
        self.coefficients = self.model.coefficients
        self.plan = plan
        self.cached = {}

    def predict_base(self, group):
        if self.model._conditioned:
            raise ValueError("Canonical batching currently requires an unconditioned package")
        inputs = [self.model._atoms_to_inputs(atoms) for atoms in group]
        z = torch.cat([item[0] for item in inputs])
        fractional = torch.cat([item[1] for item in inputs])
        cells = torch.stack([item[2] for item in inputs])
        batches = torch.cat([item[3] + index for index, item in enumerate(inputs)])
        edges = torch.cat([item[4] + 2 * index for index, item in enumerate(inputs)], dim=1)
        images = torch.cat([item[5] for item in inputs])
        args = (z, fractional, cells, batches, edges, images)
        if self.model._dynamic_head:
            heads = self.model._head_tensor.expand(len(group)).contiguous()
            pbc = torch.tensor([atoms.pbc.tolist() for atoms in group],
                               dtype=torch.bool, device=self.model.device)
            args += (heads, pbc)
        with torch.cuda.device(self.model.device), torch.inference_mode():
            energy, force, _ = self.model.aoti_model(*args)
        return (energy.cpu().numpy().reshape(-1),
                force.cpu().numpy().reshape(len(group), 2, 3))
