"""Select a conservative correction on grouped development CV, then score a frozen candidate."""
import argparse
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from fit_diatomic_residual import EN, RADII, evaluate, force_residual, read_rows
from fit_joint_residual import sha

SCALE_RADII = {**RADII, "Be": .96, "B": .84, "N": .71, "Mg": 1.41,
               "P": 1.07, "K": 2.03, "Ca": 1.76}
ELECTRONEGATIVITY = {**EN, "Be": 1.57, "B": 2.04, "N": 3.04, "Mg": 1.31,
                     "P": 2.19, "K": .82, "Ca": 1.00}
CENTERS = np.array([.80, 1., 1.20, 1.40])
WIDTH = .18
PENALTIES = (.1, 1., 10., 100.)
FAMILIES = ("scale", "radial", "hybrid")
METRICS = ("energy_mae_eV", "force_mae_eV_per_A")
MIN_POINTS = 5
MIN_TRAIN_MOLECULES = 20
MIN_VALIDATION_MOLECULES = 6
MIN_GAIN = .05
MIN_WIN_FRACTION = .60


def collect(paths):
    groups = defaultdict(list)
    for path in paths:
        for row in read_rows(path):
            groups[tuple(sorted(row["elements"]))].append(row)
    return {pair: sorted(rows, key=lambda row: row["distance_A"]) for pair, rows in sorted(groups.items())}


def design(pair, rows, family):
    a, b = pair
    radius = SCALE_RADII[a] + SCALE_RADII[b]
    en_a, en_b = ELECTRONEGATIVITY[a], ELECTRONEGATIVITY[b]
    chemical = np.array([1., (en_a + en_b - 5.) / 2., abs(en_a - en_b) / 2., (radius - 2.) / 2.])
    e_base = np.array([row["pred_energy_eV"] for row in rows])
    f_base = np.array([row["pred_radial_force_eV_per_A"] for row in rows])
    scale_e, scale_f = np.outer(e_base - e_base[-1], chemical), np.outer(f_base, chemical)
    offsets = np.array([row["distance_A"] / radius for row in rows])[:, None] - CENTERS
    radial = np.exp(-.5 * (offsets / WIDTH) ** 2)
    radial_force = radial * offsets / (radius * WIDTH ** 2)
    radial_e = (radial[:, :, None] * chemical).reshape(len(rows), -1)
    radial_f = (radial_force[:, :, None] * chemical).reshape(len(rows), -1)
    if family == "scale":
        return scale_e, scale_f
    if family == "radial":
        return radial_e, radial_f
    return np.column_stack((scale_e, radial_e)), np.column_stack((scale_f, radial_f))


def fit(designs, groups, penalty):
    xs, ys = [], []
    for pair, rows in groups.items():
        force = designs[pair][1]
        base_force = np.array([row["pred_radial_force_eV_per_A"] for row in rows])
        normalization = np.sqrt(len(rows) * (np.mean(base_force ** 2) + .25 ** 2))
        xs.append(force / normalization)
        ys.append(force_residual(rows) / normalization)
    x, y = np.vstack(xs), np.concatenate(ys)
    return np.linalg.solve(x.T @ x + penalty * np.eye(x.shape[1]), x.T @ y)


def score(pair, rows, design_pair, coefficients):
    energy, force = design_pair
    # evaluate() groups using the supplied element ordering. Keep one canonical pair.
    rows = [{**row, "elements": pair} for row in rows]
    return evaluate(rows, energy @ coefficients, force @ coefficients)


def compare(baselines, candidates):
    result = {}
    for metric in METRICS:
        base = np.array([entry[metric] for entry in baselines])
        changed = np.array([entry[metric] for entry in candidates])
        assert (base > 0).all()
        result[metric] = {
            "baseline_macro": float(base.mean()), "candidate_macro": float(changed.mean()),
            "macro_relative_gain": float(1 - changed.mean() / base.mean()),
            "fraction_molecules_improved": float(np.mean(changed < base)),
        }
    return result


def passes(metrics):
    return all(metric["macro_relative_gain"] >= MIN_GAIN and
               metric["fraction_molecules_improved"] >= MIN_WIN_FRACTION for metric in metrics.values())


def main(initial_fit, transfer, output):
    train_paths = [initial_fit, transfer / "joined/fit-predictions.jsonl"]
    validation_path = transfer / "joined/validation-predictions.jsonl"
    validation_reference = transfer / "reference/plan.json"
    split_plan = json.loads(validation_reference.read_text())
    fit_pairs = {tuple(sorted(pair[:2])) for pair in split_plan["fit"]}
    validation_pairs = {tuple(sorted(pair[:2])) for pair in split_plan["validation"]}
    train = collect(train_paths)
    assert set(collect(train_paths[1:])) <= fit_pairs
    assert validation_pairs.isdisjoint(train)
    train = {pair: rows for pair, rows in train.items() if len(rows) >= MIN_POINTS}
    assert len(train) >= MIN_TRAIN_MOLECULES
    base = [evaluate([{**row, "elements": pair} for row in rows], 0., 0.) for pair, rows in train.items()]
    cv = []
    for family in FAMILIES:
        designs = {pair: design(pair, rows, family) for pair, rows in train.items()}
        for penalty in PENALTIES:
            candidates = []
            for pair, rows in train.items():
                other = {p: group for p, group in train.items() if p != pair}
                coefficients = fit(designs, other, penalty)
                candidates.append(score(pair, rows, designs[pair], coefficients))
            comparison = compare(base, candidates)
            cv.append({"family": family, "penalty": penalty, "comparison": comparison,
                       "passes_cv": passes(comparison), "mean_macro_gain": float(
                           np.mean([metric["macro_relative_gain"] for metric in comparison.values()]))})
    output.mkdir()
    chosen = max((trial for trial in cv if trial["passes_cv"]), key=lambda trial: trial["mean_macro_gain"],
                 default=None)
    report = {"source_sha256": sha(Path(__file__)), "train_files": {str(p): sha(p) for p in train_paths},
              "training_molecules": list(train), "grouped_cv": cv, "selected": chosen,
              "minimum_gain_each_metric": MIN_GAIN, "minimum_win_fraction_each_metric": MIN_WIN_FRACTION,
              "official_data_used": False, "broad_holdout_used": False}
    (output / "selection.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    if chosen is None:
        print(json.dumps({"passes_cv": False, "best_development_trial": max(cv, key=lambda x: x["mean_macro_gain"])}))
        return
    family = chosen["family"]
    train_designs = {pair: design(pair, rows, family) for pair, rows in train.items()}
    coefficients = fit(train_designs, train, chosen["penalty"])
    frozen = {"frozen_at_utc": datetime.now(timezone.utc).isoformat(), "family": family,
              "coefficients": coefficients.tolist(), "selection_sha256": sha(output / "selection.json"),
              "validation_split_plan_sha256": sha(validation_reference)}
    (output / "frozen-candidate.json").write_text(json.dumps(frozen, indent=2, allow_nan=False) + "\n")

    validation = collect([validation_path])
    assert set(validation) <= validation_pairs
    all_validation = {str(pair): len(rows) for pair, rows in validation.items()}
    validation = {pair: rows for pair, rows in validation.items() if len(rows) >= MIN_POINTS}
    result = {"eligible_molecules": len(validation), "validation_points_by_molecule": all_validation,
              "validation_predictions_sha256": sha(validation_path), "passes_validation": False}
    if len(validation) >= MIN_VALIDATION_MOLECULES:
        baseline, candidate = [], []
        for pair, rows in validation.items():
            baseline.append(evaluate([{**row, "elements": pair} for row in rows], 0., 0.))
            candidate.append(score(pair, rows, design(pair, rows, family), coefficients))
        result["comparison"] = compare(baseline, candidate)
        result["passes_validation"] = passes(result["comparison"])
    (output / "validation.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("initial_fit", type=Path)
    parser.add_argument("transfer", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    main(args.initial_fit, args.transfer, args.output)
