"""Freeze and generate a new independent, molecule-disjoint DFT holdout."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from pyscf import __version__, dft, gto, lib
from pyscf.data.nist import BOHR, HARTREE2EV

from build_diatomics_dev import FIT, VALIDATION
from fit_diatomic_residual import RADII

# Triples contain the elements and 2S. Some open-shell cases deliberately
# stress transfer beyond the original closed-shell fit.
MOLECULES = [
    ("H", "Li", 0), ("H", "Na", 0), ("H", "Al", 0), ("Li", "Na", 0),
    ("Li", "Al", 0), ("Na", "Al", 0), ("Na", "Br", 0), ("Al", "Br", 0),
    ("F", "Cl", 0), ("F", "Br", 0), ("Cl", "Br", 0),
    ("O", "S", 2), ("C", "F", 1), ("Si", "F", 1), ("Si", "Cl", 1),
    ("Si", "Br", 1), ("S", "F", 1), ("O", "F", 1),
]
RATIOS = (.70, .78, .86, .94, 1.02, 1.10, 1.22, 1.38, 1.55, 1.72)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(a, b, spin, distance):
    mol = gto.M(atom=[(a, (0, 0, 0)), (b, (distance, 0, 0))], unit="Angstrom",
                basis="def2-svp", charge=0, spin=spin, verbose=0)
    model = dft.UKS(mol) if spin else dft.RKS(mol)
    model.xc = "PBE"
    model.grids.level = 3
    model.conv_tol = 1e-9
    model.max_cycle = 120
    energy = model.kernel()
    row = {"converged": False, "energy_eV": None, "radial_force_eV_per_A": None}
    if model.converged:
        force = -model.nuc_grad_method().kernel()[1, 0] * HARTREE2EV / BOHR
        if np.isfinite([energy, force]).all():
            row.update(converged=True, energy_eV=float(energy * HARTREE2EV),
                       radial_force_eV_per_A=float(force))
    return row


def main(root, candidate, compiled):
    root.mkdir()
    previous = {tuple(sorted((a, b))) for a, b, _ in FIT + VALIDATION}
    pairs = {tuple(sorted((a, b))) for a, b, _ in MOLECULES}
    assert len(pairs) == len(MOLECULES) and pairs.isdisjoint(previous)
    assert all(a != b and a in RADII and b in RADII for a, b in pairs)
    plan = {
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "molecules_with_2s": MOLECULES, "ratios": RATIOS,
        "method": "PySCF neutral PBE/def2-SVP, RKS singlet or UKS specified spin, grid level 3",
        "pyscf_version": __version__, "source_sha256": sha(Path(__file__)),
        "candidate_sha256": sha(candidate), "compiled_sha256": sha(compiled),
        "periodic_box_A_for_inference": 50,
        "min_valid_points_per_molecule": 7, "min_passing_molecules": 14,
        "min_mean_molecule_relative_gain_each_metric": .05,
        "min_fraction_of_molecules_improving_each_metric": .60,
        "official_data_used": False,
    }
    (root / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    lib.num_threads(4)
    path = root / "reference.jsonl"
    with path.open("x", buffering=1) as f:
        for a, b, spin in MOLECULES:
            success = 0
            for ratio in RATIOS:
                distance = round((RADII[a] + RADII[b]) * ratio, 6)
                try:
                    values = reference(a, b, spin, distance)
                except (RuntimeError, np.linalg.LinAlgError) as exc:
                    values = {"converged": False, "energy_eV": None, "error": str(exc)}
                success += int(values["converged"])
                row = {"elements": [a, b], "spin_2s": spin, "distance_A": distance, **values}
                f.write(json.dumps(row, allow_nan=False) + "\n")
            print(a + b, success, "/", len(RATIOS), flush=True)
    (root / "reference-sha256.json").write_text(json.dumps({"reference.jsonl": sha(path)}, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("compiled", type=Path)
    args = parser.parse_args()
    main(args.root, args.candidate, args.compiled)
