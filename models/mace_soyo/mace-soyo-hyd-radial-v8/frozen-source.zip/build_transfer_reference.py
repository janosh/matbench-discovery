"""Generate independent development curves with molecule-disjoint splits."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from pyscf import __version__, lib

from build_broad_holdout import MOLECULES, reference, sha
from build_diatomics_dev import FIT, VALIDATION
from fit_diatomic_residual import RADII

FIT_MOLECULES = (
    ("Be", "O", 0), ("Be", "F", 1), ("B", "N", 2), ("B", "O", 1),
    ("B", "F", 0), ("N", "O", 1), ("N", "S", 1), ("N", "Cl", 2),
    ("Mg", "O", 0), ("Mg", "F", 1), ("Mg", "Cl", 1), ("Al", "O", 1),
    ("P", "N", 0), ("P", "O", 1), ("P", "F", 0), ("K", "F", 0),
    ("K", "Cl", 0), ("Ca", "O", 0), ("Ca", "Cl", 1),
)
VALIDATION_MOLECULES = (
    ("Be", "Cl", 1), ("B", "Cl", 0), ("N", "F", 2), ("Mg", "S", 0),
    ("Al", "S", 1), ("P", "Cl", 0), ("K", "Br", 0), ("Ca", "F", 1),
)
SCALE_RADII = {**RADII, "Be": .96, "B": .84, "N": .71, "Mg": 1.41,
               "P": 1.07, "K": 2.03, "Ca": 1.76}
RATIOS = (.74, .84, .94, 1.04, 1.16, 1.30, 1.47, 1.65)


def pair_ids(groups):
    return {tuple(sorted((a, b))) for a, b, _ in groups}


def main(output):
    train, validation = pair_ids(FIT_MOLECULES), pair_ids(VALIDATION_MOLECULES)
    assert len(train) == len(FIT_MOLECULES) and len(validation) == len(VALIDATION_MOLECULES)
    assert train.isdisjoint(validation)
    assert (train | validation).isdisjoint(pair_ids([*FIT, *VALIDATION, *MOLECULES]))
    output.mkdir()
    plan = {
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": sha(Path(__file__)),
        "reference_source_sha256": sha(Path(__file__).with_name("build_broad_holdout.py")),
        "fit": FIT_MOLECULES,
        "validation": VALIDATION_MOLECULES,
        "scale_radii_A": SCALE_RADII,
        "ratios": RATIOS,
        "pyscf": __version__,
        "method": "Neutral PBE/def2-SVP, RKS for singlets and UKS otherwise, level 3 grid",
        "spin_meaning": "Specified 2S electronic state for development reference calculations",
        "official_inputs_or_labels_used": False,
    }
    (output / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    lib.num_threads(4)
    counts = {}
    for split, molecules in (("fit", FIT_MOLECULES), ("validation", VALIDATION_MOLECULES)):
        counts[split] = {"attempted": 0, "converged": 0}
        with (output / f"{split}.jsonl").open("x", buffering=1) as file:
            for a, b, spin in molecules:
                converged = 0
                for ratio in RATIOS:
                    distance = round((SCALE_RADII[a] + SCALE_RADII[b]) * ratio, 6)
                    try:
                        values = reference(a, b, spin, distance)
                    except (RuntimeError, np.linalg.LinAlgError) as exc:
                        values = {"converged": False, "energy_eV": None,
                                  "radial_force_eV_per_A": None, "error": str(exc)}
                    converged += int(values["converged"])
                    row = {"elements": [a, b], "distance_A": distance, "spin_2s": spin, **values}
                    file.write(json.dumps(row, allow_nan=False) + "\n")
                counts[split]["attempted"] += len(RATIOS)
                counts[split]["converged"] += converged
                print(f"{split} {a}-{b} {converged}/{len(RATIOS)}", flush=True)
    manifest = {"counts": counts, "sha256": {
        name: sha(output / name) for name in ("plan.json", "fit.jsonl", "validation.jsonl")
    }}
    (output / "reference-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    main(parser.parse_args().output)
