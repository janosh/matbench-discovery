"""Screen a normalized joint energy and force loss on expanded fit molecules."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

import fit_transfer_candidate as transfer
from fit_diatomic_residual import evaluate, force_residual
from fit_joint_residual import sha

ENERGY_WEIGHTS = (.25, 1., 4., 16.)
PENALTIES = (.2, .85, 2., 5.)


def fit(designs, groups, penalty, energy_weight):
    xs, ys = [], []
    for pair, rows in groups.items():
        energy, force = designs[pair]
        base_force = np.array([row["pred_radial_force_eV_per_A"] for row in rows])
        energy_residual = np.array([row["energy_eV"] - row["pred_energy_eV"] for row in rows])
        force_scale = np.sqrt(len(rows) * (np.mean(base_force ** 2) + .25 ** 2))
        radius = sum(transfer.SCALE_RADII[element] for element in pair)
        energy_factor = np.sqrt(energy_weight) / (force_scale * radius)
        xs.extend((force / force_scale, (energy - energy.mean(axis=0)) * energy_factor))
        ys.extend((force_residual(rows) / force_scale,
                   (energy_residual - energy_residual.mean()) * energy_factor))
    x, y = np.vstack(xs), np.concatenate(ys)
    return np.linalg.solve(x.T @ x + penalty * np.eye(x.shape[1]), x.T @ y)


def main(initial_fit, run, output):
    reference_plan = json.loads((run / "reference/plan.json").read_text())
    fit_path = run / "joined/fit-predictions.jsonl"
    train_paths = (initial_fit, fit_path)
    fit_pairs = {tuple(sorted(pair[:2])) for pair in reference_plan["fit"]}
    held_pairs = {tuple(sorted(pair[:2])) for pair in reference_plan["validation"]}
    train = transfer.collect(train_paths)
    assert set(transfer.collect([fit_path])) <= fit_pairs and held_pairs.isdisjoint(train)
    train = {pair: rows for pair, rows in train.items() if len(rows) >= transfer.MIN_POINTS}
    assert len(train) >= transfer.MIN_TRAIN_MOLECULES
    designs = {pair: transfer.design(pair, rows, "radial") for pair, rows in train.items()}
    baseline = [evaluate([{**row, "elements": pair} for row in rows], 0., 0.) for pair, rows in train.items()]
    output.mkdir()
    grid_path = output / "grid-freeze.json"
    grid = {"frozen_at_utc": datetime.now(timezone.utc).isoformat(),
            "source_sha256": sha(Path(__file__)), "design_source_sha256": sha(Path(transfer.__file__)),
            "training_file_sha256": {str(path): sha(path) for path in train_paths},
            "energy_weights": ENERGY_WEIGHTS, "ridge_penalties": PENALTIES,
            "minimum_gain_each_metric": transfer.MIN_GAIN,
            "minimum_win_fraction_each_metric": transfer.MIN_WIN_FRACTION,
            "official_data_used": False, "heldout_labels_used_to_choose_grid": False}
    grid_path.write_text(json.dumps(grid, indent=2, allow_nan=False) + "\n")
    trials = []
    for energy_weight in ENERGY_WEIGHTS:
        for penalty in PENALTIES:
            scores = []
            for pair, rows in train.items():
                others = {p: group for p, group in train.items() if p != pair}
                coef = fit(designs, others, penalty, energy_weight)
                scores.append(transfer.score(pair, rows, designs[pair], coef))
            metrics = transfer.compare(baseline, scores)
            trials.append({"energy_weight": energy_weight, "penalty": penalty, "metrics": metrics,
                           "passes_cv": transfer.passes(metrics), "mean_gain": float(
                               np.mean([metric["macro_relative_gain"] for metric in metrics.values()]))})
    selected = max((trial for trial in trials if trial["passes_cv"]), key=lambda trial: trial["mean_gain"],
                   default=None)
    (output / "train-screen.json").write_text(json.dumps({
        "grid_sha256": sha(grid_path), "trials": trials, "selected": selected,
    }, indent=2, allow_nan=False) + "\n")
    if selected is None:
        print(json.dumps({"selected": None, "best": max(trials, key=lambda trial: trial["mean_gain"])}))
        return
    print(json.dumps({"selected": selected}))
    weight = selected["energy_weight"]
    transfer.PENALTIES = (selected["penalty"],)
    transfer.FAMILIES = ("radial",)
    transfer.fit = lambda designs, groups, penalty: fit(designs, groups, penalty, weight)
    transfer.main(initial_fit, run, output / "frozen-evaluation")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("initial_fit", type=Path)
    parser.add_argument("run", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    main(args.initial_fit, args.run, args.output)
