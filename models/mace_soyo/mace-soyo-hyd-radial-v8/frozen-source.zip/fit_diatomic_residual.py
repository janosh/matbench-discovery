"""Pilot conservative radial residual fitted exclusively on independent fit molecules."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

RADII = {"H": .31, "Li": 1.28, "C": .76, "O": .66, "F": .57, "Na": 1.66,
         "Al": 1.21, "Si": 1.11, "S": 1.05, "Cl": 1.02, "Br": 1.20}
EN = {"H": 2.20, "Li": .98, "C": 2.55, "O": 3.44, "F": 3.98, "Na": .93,
      "Al": 1.61, "Si": 1.90, "S": 2.58, "Cl": 3.16, "Br": 2.96}
CENTERS = np.linspace(.70, 1.60, 7)
WIDTH = .16
PENALTIES = (.03, .3, 3., 30.)


def read_rows(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert all(a != b for a, b in (row["elements"] for row in rows))
    return [row for row in rows if row["converged"] and row["energy_eV"] is not None]


def design(rows):
    energy, force = [], []
    for row in rows:
        a, b = row["elements"]
        scale = RADII[a] + RADII[b]
        offset = row["distance_A"] / scale - CENTERS
        radial = np.exp(-.5 * (offset / WIDTH) ** 2)
        chemistry = np.asarray([1., (EN[a] + EN[b] - 5.) / 2., abs(EN[a] - EN[b]) / 2.])
        values = np.outer(radial, chemistry)
        energy.append(values.ravel())
        force.append((values * (offset / (scale * WIDTH ** 2))[:, None]).ravel())
    return np.asarray(energy), np.asarray(force)


def force_residual(rows):
    return np.array([r["radial_force_eV_per_A"] - r["pred_radial_force_eV_per_A"] for r in rows])


def fit(design_force, residual, alpha):
    return np.linalg.solve(design_force.T @ design_force + alpha * np.eye(design_force.shape[1]),
                           design_force.T @ residual)


def evaluate(rows, energy_delta, force_delta):
    reference = np.array([row["energy_eV"] for row in rows])
    predicted = np.array([row["pred_energy_eV"] for row in rows]) + energy_delta
    by_molecule = [tuple(r["elements"]) for r in rows]
    energy_errors = []
    for pair in sorted(set(by_molecule)):
        mask = np.array([x == pair for x in by_molecule])
        ref = reference[mask]
        pred = predicted[mask]
        energy_errors.extend(np.abs((ref - ref.min()) - (pred - pred.min())))
    return {
        "energy_mae_eV": float(np.mean(energy_errors)),
        "force_mae_eV_per_A": float(np.abs(force_residual(rows) - force_delta).mean()),
        "molecules": len(set(by_molecule)), "scored_rows": len(rows),
    }


def main(results, output):
    output.mkdir()
    train = read_rows(results / "fit-predictions.jsonl")
    _, force_train = design(train)
    residual = force_residual(train)
    groups = [tuple(r["elements"]) for r in train]
    cv = []
    for alpha in PENALTIES:
        errors = []
        for pair in sorted(set(groups)):
            held = np.array([group == pair for group in groups])
            coef = fit(force_train[~held], residual[~held], alpha)
            errors.append(np.abs(force_train[held] @ coef - residual[held]).mean())
        cv.append(float(np.mean(errors)))
    selected = PENALTIES[int(np.argmin(cv))]
    weights = fit(force_train, residual, selected)
    (output / "selection.json").write_text(json.dumps({
        "scope": "Conservative energy/force correction for a development prototype only",
        "train_molecules": sorted(set(groups)), "penalties": PENALTIES, "fit_cv_force_mae": cv,
        "selected_penalty": selected, "coefficients": weights.tolist(), "official_data_used": False,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "fit_predictions_sha256": hashlib.sha256((results / "fit-predictions.jsonl").read_bytes()).hexdigest(),
    }, indent=2) + "\n")
    validation = read_rows(results / "validation-predictions.jsonl")
    assert set(groups).isdisjoint(tuple(row["elements"]) for row in validation)
    energy_val, force_val = design(validation)
    comparison = {
        "baseline": evaluate(validation, 0., 0.),
        "candidate": evaluate(validation, energy_val @ weights, force_val @ weights),
        "scope": "Independent light-element heteronuclear holdout. No official score.",
    }
    (output / "comparison.json").write_text(json.dumps(comparison, indent=2) + "\n")
    print(json.dumps(comparison, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    main(args.results, args.output)
