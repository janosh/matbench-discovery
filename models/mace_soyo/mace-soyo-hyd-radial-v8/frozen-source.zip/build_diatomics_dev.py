"""Generate independent heteronuclear PBE validation data without benchmark inputs."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from pyscf import __version__, dft, gto, lib
from pyscf.data.nist import BOHR, HARTREE2EV

# Neutral singlets, partitioned by molecule before computing references.
FIT = [("H", "F", 0.88), ("H", "Cl", 1.33), ("Li", "F", 1.85),
       ("Li", "Br", 2.48), ("Na", "Cl", 2.68), ("C", "O", 1.42),
       ("Si", "O", 1.77), ("C", "S", 1.81), ("Al", "F", 1.78)]
VALIDATION = [("H", "Br", 1.51), ("Li", "Cl", 2.30), ("Na", "F", 2.23),
              ("Si", "S", 2.16), ("Al", "Cl", 2.23)]
RATIOS = [0.72, 0.80, 0.88, 0.96, 1.04, 1.12, 1.25, 1.40, 1.55]


def calculate(pair, distance):
    first, second = pair
    mol = gto.M(atom=[(first, (0, 0, 0)), (second, (0, 0, distance))],
                unit="Angstrom", basis="def2-svp", charge=0, spin=0, verbose=0)
    method = dft.RKS(mol)
    method.xc = "PBE"
    method.grids.level = 3
    method.conv_tol = 1e-9
    method.max_cycle = 120
    energy = method.kernel()
    result = {"energy_eV": None, "radial_force_eV_per_A": None, "converged": bool(method.converged)}
    if method.converged:
        force = -method.nuc_grad_method().kernel()[1, 2] * HARTREE2EV / BOHR
        if np.isfinite([energy, force]).all():
            result.update(energy_eV=float(energy * HARTREE2EV), radial_force_eV_per_A=float(force))
    return result


def main(output):
    output.mkdir(parents=True, exist_ok=True)
    lib.num_threads(4)
    assert all(a != b for a, b, _ in FIT + VALIDATION)
    assert {tuple(sorted((a, b))) for a, b, _ in FIT}.isdisjoint(
        tuple(sorted((a, b))) for a, b, _ in VALIDATION
    )
    plan = {
        "method": "PySCF restricted Kohn-Sham PBE/def2-SVP, neutral singlets, grid level 3",
        "pyscf_version": __version__, "fit_molecules": FIT, "validation_molecules": VALIDATION,
        "distance_ratios": RATIOS, "official_data_used": False,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    with (output / "reference-plan.json").open("x") as f:
        json.dump(plan, f, indent=2)
    counts = {}
    for split, molecules in (("fit", FIT), ("validation", VALIDATION)):
        counts[split] = {"valid": 0, "failed": 0}
        with (output / f"{split}-reference.jsonl").open("x", buffering=1) as f:
            for a, b, scale in molecules:
                for ratio in RATIOS:
                    distance = round(scale * ratio, 6)
                    try:
                        result = calculate((a, b), distance)
                    except (RuntimeError, np.linalg.LinAlgError) as exc:
                        result = {"converged": False, "energy_eV": None, "error": str(exc)}
                    key = "valid" if result["converged"] and result["energy_eV"] is not None else "failed"
                    counts[split][key] += 1
                    f.write(json.dumps({"elements": [a, b], "distance_A": distance, **result},
                                       allow_nan=False) + "\n")
                print(split, a + b, counts[split], flush=True)
    report = {
        "counts": counts, "official_data_used": False,
        "hashes": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in output.glob("*-reference.jsonl")},
    }
    (output / "reference-verification.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    main(parser.parse_args().output)
