"""Fit an energy/force-consistent residual on the original development molecules."""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np

from fit_diatomic_residual import PENALTIES, design, evaluate, force_residual, read_rows

ENERGY_WEIGHTS = (1., 4., 16.)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def centered_energy(rows, features):
    residual = np.array([r["energy_eV"] - r["pred_energy_eV"] for r in rows])
    pairs = [tuple(row["elements"]) for row in rows]
    centered = features.copy()
    for pair in set(pairs):
        subset = np.array([p == pair for p in pairs])
        centered[subset] -= centered[subset].mean(axis=0)
        residual[subset] -= residual[subset].mean()
    return centered, residual


def solve(rows, alpha, energy_weight):
    energy, force = design(rows)
    centered, residual = centered_energy(rows, energy)
    counts = Counter(tuple(row["elements"]) for row in rows)
    equal_molecule_weights = np.sqrt([1 / counts[tuple(row["elements"])] for row in rows])
    force_part = force * equal_molecule_weights[:, None]
    energy_part = centered * equal_molecule_weights[:, None] * np.sqrt(energy_weight)
    x = np.concatenate((force_part, energy_part))
    y = np.concatenate((force_residual(rows) * equal_molecule_weights,
                        residual * equal_molecule_weights * np.sqrt(energy_weight)))
    return np.linalg.solve(x.T @ x + alpha * np.eye(x.shape[1]), x.T @ y)


def metrics(rows, coefficients):
    energy, force = design(rows)
    return evaluate(rows, energy @ coefficients, force @ coefficients)


def main(result_dir, output):
    output.mkdir()
    fit_path = result_dir / "fit-predictions.jsonl"
    rows = read_rows(fit_path)
    pairs = sorted({tuple(row["elements"]) for row in rows})
    cv = []
    for alpha in PENALTIES:
        for weight in ENERGY_WEIGHTS:
            losses = []
            for pair in pairs:
                train = [r for r in rows if tuple(r["elements"]) != pair]
                val = [r for r in rows if tuple(r["elements"]) == pair]
                baseline = evaluate(val, 0., 0.)
                result = metrics(val, solve(train, alpha, weight))
                losses.append(np.mean([result[key] / baseline[key]
                                       for key in ("energy_mae_eV", "force_mae_eV_per_A")]))
            cv.append({"alpha": alpha, "energy_weight": weight, "macro_relative_error": float(np.mean(losses))})
    chosen = min(cv, key=lambda c: c["macro_relative_error"])
    coefficients = solve(rows, chosen["alpha"], chosen["energy_weight"])
    (output / "selection.json").write_text(json.dumps({
        "source_sha256": sha(Path(__file__)), "fit_predictions_sha256": sha(fit_path),
        "train_molecules": pairs, "cv": cv, "selected": chosen,
        "coefficients": coefficients.tolist(), "official_data_used": False,
    }, indent=2) + "\n")
    holdout = read_rows(result_dir / "validation-predictions.jsonl")
    assert set(pairs).isdisjoint(tuple(r["elements"]) for r in holdout)
    result = {
        "baseline": evaluate(holdout, 0., 0.),
        "candidate": metrics(holdout, coefficients),
        "scope": "Re-used initial five-molecule development split; broader holdout and official data excluded.",
    }
    (output / "comparison.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    main(args.results, args.output)
